import ShitheadGame from './components/ShitheadGame';
import './index.css';

function App() {
  return <ShitheadGame />;
}
export default App;
