# Shithead Card Game

A React-based browser game with sound effects and animations.